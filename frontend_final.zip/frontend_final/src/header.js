import React from 'react'
import header from './components/header';

const header = () => {
  return (
    <div>
      header
    </div>
  )
}
export default header

