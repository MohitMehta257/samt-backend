import { useEffect, useRef, useState } from 'react';
import './App.css';
import {  Dropdown } from 'bootstrap';
import Employee from './components/Employee';
import { BrowserRouter as Router, Route, Switch, Routes, Link, Navigate, useParams } from 'react-router-dom';
import {useNavigate} from 'react-router-dom';
import axios from 'axios';
import Button from 'react-bootstrap/Button';

import {isManager} from './components/Login';



function App() {

  const{access}=useParams();
  // if(access)
  // {
  //   access="manager"
  // }

  // if(isManager==false)
  // {
  //   access="employee"
  // }

  const handleEmployeeClick=(value)=>{
   //window.open('src\components\Employee.js',value,'_blank');
   //window.open(navigate(`/employee/${value}`));
    window.open(`/employee/${value}/${viewMonth}/${viewYear}/${access}`);
  }

  
  const[viewMonth,setViewMonth]=useState(null);
  const[viewYear,setViewYear]=useState("View Year");

  const[users,setUsers]=useState([]);

  const navigate=useNavigate();


  const handleLogOut=()=>{
    console.log('Logging Out');
    localStorage.removeItem('token');
    navigate('/');
  }


  const handleViewMonth=(value)=>{
    setViewMonth(value);
    fetchData();
     
    
  }

  const handleViewYear=(value)=>{
    setViewYear(value);
  }

  async function fetchData(month){
    try{
      setViewMonth(month);
      users.splice(0,users.length);
      const response=await fetch('http://localhost:8084/api/shift/all?month='+month+'&year='+viewYear,{
        headers:{
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      })
      const jsonData=await response.json();
      setUsers(jsonData);
    }
    catch(error)
    {
      console.error('Error fetching data: ',error);
    }
  }

  const[searchQuery,setSearchQuery]=useState('');
  const[employee,setEmployees]=useState(users);

  const handleSearchChange=event=>{
    setSearchQuery(event.target.value);
  }

  const filteredEmployees=employee.filter(employee=>employee.employeeName.toLowerCase().includes(searchQuery.toLowerCase()));


  const[uploadMonth,setUploadMonth]=useState("Month");
  const[uploadYear,setUploadYear]=useState("Year");

  users.map(user=>(
    user.totalCount=user.afternoonShiftCount+user.morningShiftCount+user.nightShiftCount+user.general+user.plannedLeave+user.unplannedLeave
  ))

  for(let i=1;i<=users.length;i++)
  {
    users[i-1]['id']=i;
  }
  const handleUploadMonth=(value)=>{
    setUploadMonth(value);
  }


  const handleUploadYear=(value)=>{
    setUploadYear(value);
  }

  

  // const handleFileChange=(event)=>{
  //   setSelectedFile(event.target.files[0]);
  //   alert(event.target.files[0].name +" file successfully uploaded");
  // }

  // const handleUpload=()=>{
  //   if(!selectedFile)
  //     {
  //       alert("Please select a file to upload");
  //       return;
  //     }

  //     const data=new FormData();
  //     data.append('file',selectedFile);

  //     fetch('http://localhost:8000/api/shift/upload?'+"month="+uploadMonth+"&year="+uploadYear,{
  //       method:'POST',
  //       body:data,
  
        
  //         }).then(response=>response.json())
  //         .then(data=>{
  //       console.log("File uploaded successfully: ",data);
  //     })
  //     .catch(error=>{
  //       console.error("Error uploading file: ",error);
  //     });
  //     //users.splice(0,users.length);
  //     window.location.reload();
  //     window.location.reload();


  // }

  const[selectedFile,setSelectedFile]=useState(null);
  const[isFileSelected,setIsFileSelected]=useState(null);
  const[uploading,setUploading]=useState(null);
  const[uploadError,setUploadError]=useState(null);

  const fileSelectedHandler=event=>{
    setSelectedFile(event.target.files[0]);
    setIsFileSelected(true);
  };

  const fileUploadHandler=async()=>{
    try{
      setUploading(true);
      const formData=new FormData();
      formData.append('file',selectedFile);

      const response=await axios.post('http://localhost:8084/api/shift/upload?'+"month="+uploadMonth+"&year="+uploadYear,formData,{
        headers:{
          Authorization: `Bearer ${localStorage.getItem('token')}`
        }
      }
  
      );

      console.log('File Uploaded successfully');

      setSelectedFile(null);
      setIsFileSelected(null);
      setUploading(false);
      setUploadError(null);
    }

    catch(error){
      console.error('Error uploading file: ',error);
      setUploadError('Error uploading file. Please try again.');
      setUploading(false);
    }
  };

  const cancelUpload=()=>{
    setSelectedFile(null);
    setIsFileSelected(false);
    setUploadError(null);
  }




  // useEffect(()=>{
  //   fetch('http://localhost:8000/api/shift/all?month='+viewMonth+"&year="+viewYear)
  //   .then(response=>response.json())
  //   .then(data=>setUsers(data))
  //   .catch(error=>console.error("error fetching users: ",error))
  // },[]);

  // {users.map(user=>(
  //   user.totalCount=user.afternoonShiftCount+user.morningShiftCount+user.nightShiftCount
  // ))}
  // sort on the basis of employee name

  users.sort((a,b)=>{
    if(a.employee.employeeName<b.employee.employeeName)
      {
        return -1;
      }

    if(a.employee.employeeName>b.employee.employeeName)
      {
        return 1;
      }

      return 0;
  })


  const containerRef=useRef(null);

  const scrollLeft=()=>{
    if(containerRef.current)
      {
        containerRef.current.scrollBy({
          left:-200,
          behavior:'smooth'
        });
      }
  }

  const scrollRight=()=>{
    if(containerRef.current)
      {
        containerRef.current.scrollBy({
          left:200,
          behavior:'smooth'
        });
      }
  }
 
  const inputFile=useRef(null);

  const onButtonClick=()=>{
    inputFile.current.click();
  }

  const[isHovering,setIsHovering]=useState(false);
  const[hoveredCell, setHoveredCell]=useState(null);

  const handleCellHover=(cellId)=>{
    setHoveredCell(cellId);
  }

  const handleCellLeave=()=>{
    setHoveredCell(null);
  }
  

  const handleMouseOver=()=>{
    setIsHovering(true);
  }

  const handleMouseOut=()=>{
    setIsHovering(false);
  }

  let time=new Date().toLocaleTimeString();

  const[currentTime,setCurrentTime]=useState(time);

  const updateTime=()=>{
    let time=new Date().toLocaleTimeString();
    setCurrentTime(time);
  }
  
  setInterval(updateTime,1000);

  const now=new Date();
  const daysOfWeek=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']

  const dayOfWeek=daysOfWeek[now.getDay()];
  


  return (
  
  
     <div class="bg-slate-50"> 
    <div>

      <div class="bg-volks h-20 pt-2 flex flex-row">
        <div class="w-2/12 ml-10 h-2">
          <img class="h-11 w-52" src="https://www.firstnaukri.com/careers/customised/landingpage/volkswagen/images/logo1.png" alt=""></img>
        </div>

        <div class="relative inline-block text-left">
  <div class="ml-8 bg-volks">
    <button onClick={handleLogOut} type="button" class="border-hidden hover:bg-black inline-flex w-full justify-center gap-x-1.5 rounded-md bg-volks px-3 py-2 text-sm font-semibold text-white   cursor-pointer" id="menu-button" aria-expanded="true" aria-haspopup="true">
      Log Out
     
    </button>
  </div>

 
  <div class="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none" role="menu" aria-orientation="vertical" aria-labelledby="menu-button" tabindex="-1">
  </div>
</div>

    <div class="mt-3 flex flex-row ml-[625px]">

      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="bi bi-search" viewBox="0 0 16 16">
        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"/>
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="ml-8 bi bi-check-circle" viewBox="0 0 16 16">
    <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
    <path d="m10.97 4.97-.02.022-3.473 4.425-2.093-2.094a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-1.071-1.05"/>
      </svg>

      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="ml-8 bi bi-envelope-x" viewBox="0 0 16 16">
        <path d="M2 2a2 2 0 0 0-2 2v8.01A2 2 0 0 0 2 14h5.5a.5.5 0 0 0 0-1H2a1 1 0 0 1-.966-.741l5.64-3.471L8 9.583l7-4.2V8.5a.5.5 0 0 0 1 0V4a2 2 0 0 0-2-2zm3.708 6.208L1 11.105V5.383zM1 4.217V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v.217l-7 4.2z"/>
        <path d="M16 12.5a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0m-4.854-1.354a.5.5 0 0 0 0 .708l.647.646-.647.646a.5.5 0 0 0 .708.708l.646-.647.646.647a.5.5 0 0 0 .708-.708l-.647-.646.647-.646a.5.5 0 0 0-.708-.708l-.646.647-.646-.647a.5.5 0 0 0-.708 0"/>
      </svg>


      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="ml-8 bi bi-bell" viewBox="0 0 16 16">
        <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2M8 1.918l-.797.161A4 4 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4 4 0 0 0-3.203-3.92zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5 5 0 0 1 13 6c0 .88.32 4.2 1.22 6"/>
      </svg>


      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="ml-8 bi bi-person-circle" viewBox="0 0 16 16">
        <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0"/>
        <path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8m8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1"/>
      </svg>

      </div>
      
      </div>


      <div class="w-full h-80 bg-ballon">
        <div class="ml-[850px] flex flex-row pt-8">

          <div class="text-white text-sm text-white w-20 flex flex-row  rounded hover:bg-slate-400 cursor-pointer hover:text-blue-800">
          {/* <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="mt-1 bi bi-three-dots-vertical" viewBox="0 0 16 16">
            <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0m0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0"/>
          </svg>
          &nbsp;Actions */}
          </div>

          <div class="text-white text-sm w-20 flex flex-row  rounded ml-4 hover:bg-slate-400 cursor-pointer hover:text-blue-800">
          {/* <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="mt-1 bi bi-pencil" viewBox="0 0 16 16">
            <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
          </svg>
          &nbsp;Header */}
          </div>


          <div class="text-white text-sm w-24 flex flex-row rounded ml-4 hover:bg-slate-400 cursor-pointer hover:text-blue-800">
          {/* <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" class="mt-1 bi bi-calendar" viewBox="0 0 16 16">
            <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5M1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4z"/>
          </svg>
          &nbsp;As of Today */}
          </div>


        </div>

        <div class="flex flex-row">
        <div class="ml-8 h-1/5 w-1/5">
          <img class="rounded-full w-4/5 h-4/5" src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png" alt=""></img>
        </div>

        <div class="mt-8 ml-2 ">
          <h1 class="text-3xl text-white font-bold">Rahul Jharkharia</h1>
          <p class="leading-3">{dayOfWeek}   {currentTime}</p>
          <p class="leading-3">SFIT, VWITS India</p>
          <p class="leading-3">Gurgaon (India)</p>
          <p class="text-blue-800 leading-3 hover:underline cursor:pointer">rahul.jharkharia@volkswagen.co.in</p>

        </div>

        </div>

      </div>

    {access=='manager' && (
      <div class="flex mt-2 items-right justify-end">

      {/* <div class="relative w-full">
            <input type="search" id="location-search" class="ml-[510px] block p-2.5 w-2/5 z-20 text-sm text-gray-900 bg-gray-50 rounded-e-lg border-s-gray-50 border-s-2 border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-s-gray-700  dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:border-blue-500" placeholder="Search for Employees" required />
            <button type="submit" class="absolute top-0 end-0 h-10 p-2.5 text-sm font-medium text-white bg-blue-700 rounded-e-lg border border-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                <svg class="w-4 h-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                </svg>
                <span class="sr-only">Search</span>
            </button> 
        </div> */}

      
       <div class="border ml-1 mr-2 cursor-pointer flex flex-col" >
        {/* <svg xmlns="http://www.w3.org/2000/svg" width="36" height="30" fill="currentColor" class="bi bi-upload" viewBox="0 0 16 16">
          <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5"/>
          <path d="M7.646 1.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1-.708.708L8.5 2.707V11.5a.5.5 0 0 1-1 0V2.707L5.354 4.854a.5.5 0 1 1-.708-.708z"/>
        </svg>  */}
        

          <label class="w-44 text-center bg-volks text-white h-9 items-center rounded cursor-pointer" htmlFor='input-file'><p class="mt-1">➕Add File</p></label>
        <input type="file" id='input-file' style={{display:'none'}}  onChange={fileSelectedHandler} >
        </input>
      
          {/* <Button variant="primary" >Add File</Button> */}
            {/* <button onClick={handleUpload}>Submit</button> */}
            {isFileSelected && (
              <div class="justify-evenly">
                {uploadError && <p style={{ color: 'red' }}>{uploadError}</p>}
                    <button class="bg-green-300 w-1/2 rounded text-white" onClick={fileUploadHandler} disabled={uploading}>
                        {uploading ? 'Uploading...' : 'Submit'}
                    </button>
                    <button class="w-1/2 bg-red-500 rounded text-white" onClick={cancelUpload}>Cancel</button>

              </div>
              
            )
           

            }
        </div> 
      

        <div class="">
          <div class="dropdown cursor-pointer">
                    <button style={{backgroundColor: '#5f1939',color:'white'}} class="btn btn-secondary dropdown-toggle relative" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                      {uploadYear}

                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadYear("2022")}>2022</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadYear("2023")}>2023</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadYear("2024")}>2024</a></li>
                    </ul>
          </div>
        </div>

        
          <div class="dropdown cursor-pointer">
                    <button style={{backgroundColor: '#5f1939',color:'white'}} class="btn btn-secondary dropdown-toggle relative" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                      {uploadMonth}
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Jan")}>January</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Feb")}>February</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Mar")}>March</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Apr")}>April</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("May")}>May</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Jun")}>June</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Jul")}>July</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Aug")}>August</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Sep")}>September</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Oct")}>October</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Nov")}>November</a></li>
                      <li><a class="dropdown-item text-center" onClick={()=>handleUploadMonth("Dec")}>December</a></li>
                    </ul>
          </div>
        


      </div>
    )}   
    {/* <div class="border-2 border-indigo-600 w-1/12 ml-12 bg-white">
          <button onClick={()=>setIsOpen(!isOpen)}><h6 class="ml-4">History
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-clock-history" viewBox="0 0 16 16">
    <path d="M8.515 1.019A7 7 0 0 0 8 1V0a8 8 0 0 1 .589.022zm2.004.45a7 7 0 0 0-.985-.299l.219-.976q.576.129 1.126.342zm1.37.71a7 7 0 0 0-.439-.27l.493-.87a8 8 0 0 1 .979.654l-.615.789a7 7 0 0 0-.418-.302zm1.834 1.79a7 7 0 0 0-.653-.796l.724-.69q.406.429.747.91zm.744 1.352a7 7 0 0 0-.214-.468l.893-.45a8 8 0 0 1 .45 1.088l-.95.313a7 7 0 0 0-.179-.483m.53 2.507a7 7 0 0 0-.1-1.025l.985-.17q.1.58.116 1.17zm-.131 1.538q.05-.254.081-.51l.993.123a8 8 0 0 1-.23 1.155l-.964-.267q.069-.247.12-.501m-.952 2.379q.276-.436.486-.908l.914.405q-.24.54-.555 1.038zm-.964 1.205q.183-.183.35-.378l.758.653a8 8 0 0 1-.401.432z"/>
    <path d="M8 1a7 7 0 1 0 4.95 11.95l.707.707A8.001 8.001 0 1 1 8 0z"/>
    <path d="M7.5 3a.5.5 0 0 1 .5.5v5.21l3.248 1.856a.5.5 0 0 1-.496.868l-3.5-2A.5.5 0 0 1 7 9V3.5a.5.5 0 0 1 .5-.5"/>
  </svg> 
            
            </h6></button>
          {isOpen &&(
            <div class="ml-3">
              <h6>3 Months</h6>
              <h6>6 Months</h6>
              <h6>9 Months</h6>
              <h6>12 Months</h6>

            </div> 
          )}

    </div>  */} 
    <div class="">
    {/* <div class="ml-10">
      <div class="dropdown">
                <button style={{backgroundColor: '#5f1939',color:'white'}} class="btn btn-secondary dropdown-toggle relative" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                  {viewYear}
                </button>
                <ul class="dropdown-menu cursor-pointer" aria-labelledby="dropdownMenuButton1">
                  <li><a class="dropdown-item text-center" onClick={()=>handleViewYear(2022)}>2022</a></li>
                  <li><a class="dropdown-item text-center" onClick={()=>handleViewYear(2023)}>2023</a></li>
                  <li><a class="dropdown-item text-center" onClick={()=>handleViewYear(2024)}>2024</a></li>
                </ul>
      </div>
  </div> */}

    <div class="flex">

    <div class="">
      <div class="dropdown my-4 ml-10">
                <button style={{backgroundColor: '#5f1939',color:'white'}} class="btn btn-secondary dropdown-toggle relative" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar-check" viewBox="0 0 16 16">
                    <path d="M10.854 7.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 9.793l2.646-2.647a.5.5 0 0 1 .708 0"/>
                    <path d="M3.5 0a.5.5 0 0 1 .5.5V1h8V.5a.5.5 0 0 1 1 0V1h1a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3a2 2 0 0 1 2-2h1V.5a.5.5 0 0 1 .5-.5M1 4v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V4z"/>
                  </svg>
                  {viewYear}
                </button>
                <ul class="dropdown-menu cursor-pointer" aria-labelledby="dropdownMenuButton1">
                  <li><a class="dropdown-item text-center" onClick={()=>handleViewYear(2022)}>2022</a></li>
                  <li><a class="dropdown-item text-center" onClick={()=>handleViewYear(2023)}>2023</a></li>
                  <li><a class="dropdown-item text-center" onClick={()=>handleViewYear(2024)}>2024</a></li>
                  <li><a class="dropdown-item text-center" onClick={()=>handleViewYear(2025)}>2025</a></li>
                  <li><a class="dropdown-item text-center" onClick={()=>handleViewYear(2026)}>2026</a></li>
                  <li><a class="dropdown-item text-center" onClick={()=>handleViewYear(2027)}>2027</a></li>
                </ul>
      </div>
  </div>

  <div class="bg-white  max-w-3xl my-4 ml-24  rounded overflow-hidden relative flex border-solid border-2">
    <button onClick={scrollLeft} class="h-full w-18 flex items-center top-0">
        <svg class="text-gray w-6 h-6 mt-[6px]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
      <path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5 8.25 12l7.5-7.5" />
    </svg>
    </button>

    

      {/*content */}

    
    <ul ref={containerRef} class="flex gap-x-4 py-3 px-4 m-0 overflow-x-scroll scrollbar-hide">
      <li class="cursor-pointer" onClick={()=>fetchData("Jan")}>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks">Jan </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("Feb")}>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks">Feb </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("Mar")}>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks" >Mar </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("Apr")}>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks" >Apr </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("May")}>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks" >May </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("Jun")}>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks">June </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("Jul")}>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks">July </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("Aug") }>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks" >Aug </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("Sep")}>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks" >Sept </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("Oct")}>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks" >Oct </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("Nov")}>
        <a class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks">Nov </a>
      </li>

      <li class="cursor-pointer" onClick={()=>fetchData("Dec")}>
        <a  class="text-white border-solid border-2 no-underline bg-volks py-1 px-6 inline-block rounded hover:bg-volks">Dec </a>
      </li>

    </ul>
  
    <button onClick={scrollRight} class="right-0 items-center justify-end top-0">

    <svg class="w-6 h-6 mt-[20px] text-gray mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" >
      <path stroke-linecap="round" stroke-linejoin="round" d="m8.25 4.5 7.5 7.5-7.5 7.5" />
    </svg>


    </button>
  </div>      
  </div>
    </div>

    {/* {useEffect(()=>{ 
    fetch('http://localhost:8000/api/shift/all?'+'month='+viewMonth+'&year='+viewYear)
    .then(response=>response.json())
    .then(data=>setUsers(data))
    .catch(error=>console.error("error fetching users: ",error))
  },[])} */}


      {
        <div class="text-center justify-center">
        <h1>{viewMonth} {viewYear} Rota </h1>
        </div>
        }


    <div class="mt-4 ml-12 w-11/12 "> 
      
      <table class="table table-bordered border-gray-300">
  <thead class="text-center">
    <tr>
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Employee Id</th>
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Employee </th>
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">General</th>
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Morning</th>
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">AfterNoon</th>
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Night</th>
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Total</th>
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Allowance(INR)</th>
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Sunday</th>
      {/* <th scope="col">Planed Leaves</th> */}
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Planned Leave</th>
      <th style={{backgroundColor: '#5f1939',color:'white'}} scope='col'>Unplanned Leave</th>
      {viewMonth==='Jan'  && <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Govt Holiday (26th Jan)</th>}
      {viewMonth==='May'  && <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Govt Holiday (1st May)</th>}
      {viewMonth==='Aug'  && <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Govt Holiday (15th Aug)</th>}
      {viewMonth==='Oct'  && <th style={{backgroundColor: '#5f1939',color:'white'}} scope="col">Govt Holiday (2nd Oct)</th>}
    </tr>
  </thead>
  <tbody class='text-center'>
   
      {users.map(user=>(    
        
        <tr>
        <td>{user.employee.employeeId}</td>
        <td class="cursor-pointer origin-center text-left hover:shadow-inner hover:shadow-volks" onClick={()=>handleEmployeeClick(user.employee.employeeName)}>{user.employee.employeeName}</td>
        <td>{user.general}</td>
        <td>{user.morningShiftCount}</td>
        <td>{user.afternoonShiftCount}</td>
        <td>{user.nightShiftCount}</td>

        {/* <td>{user.morningShiftCount}+{user.nightShiftCount}+{user.afternoonShiftCount}</td> */}
        <td>{user.totalCount}</td>
        <td>₹ {user.totalMoney}</td>
        <td onMouseOver={()=>handleCellHover('cell'+user.id)} onMouseOut={(handleCellLeave)}>{user.sundayCount}
          {hoveredCell==='cell'+user.id && Object.keys(user.sundayShifts)!=0 &&(
                <div id="movableDiv" className="rounded w-24 h-auto z-10 absolute bg-white border border-gray-300 p-2">
                    

                  {Object.keys(user.sundayShifts).map(key=>

                    <p class="text-xs">{key}   ({user.sundayShifts[key]})</p>
                  )
                  }
                    {/* <hr style="height:2px;border-width:0;color:gray;background-color:gray"></hr> */}
                    
                    {/* <p className='text-xs'>5 July</p>
                    
                    <p className='text-xs'>5 Sept</p>
                    
                    <p className='text-xs'>9 Dec</p> */}
                    
                    {/* Other content or components can be added here */}
                </div> 
          )}

        </td>
        <td>{user.plannedLeave}</td>
        <td>{user.unplannedLeave}</td>
        {user.holiday!==null  && (viewMonth=='Jan' || viewMonth=='May' || viewMonth=='Aug' || viewMonth=='Oct') && 
        (
          <td>✅</td>
        )}

        {user.holiday===null &&   (viewMonth=='Jan' || viewMonth=='May' || viewMonth=='Aug' || viewMonth=='Oct') && 
        (
            <td>❌</td>
        )}
       
        </tr>
      ))}
  

    {/* <tr>
      <th scope="row">1</th>
      <td>Mohit Mehta</td>
      <td>10</td>
      <td>10</td>
      <td>5</td>
      <td>25</td>
      <td>100000</td> */}
        {/* <td onMouseOver={handleMouseOver} onMouseOut={handleMouseOut}>5</td>

      {
        isHovering &&(
          <div id="movableDiv" class="w-auto h-auto z-9 absolute">
            <p className='text-sm border-solid border-2 float left inline-block'>20 June</p>
            
            
            </div>
        ) } */}
       {/* <td onMouseOver={()=>handleCellHover('cell1')} onMouseOut={handleCellLeave} className="relative">
            5 {/* Content of the table cell */}
            {/*  */}

    {/*<tr>
      <th scope="row">1</th>
      <td>Kamal Kant</td>
      <td>10</td>
      <td>10</td>
      <td>10</td>
      <td>30</td>
      <td>50000</td>
      <td>
        
         <Dropdown>
        
        <Dropdown.Toggle variant="success">Open Menu</Dropdown.Toggle>
        <Dropdown.Menu>
          <Dropdown.Item>20 June</Dropdown.Item>

        </Dropdown.Menu>
        
        </Dropdown> */}

          
{/* <button id="dropdownHoverButton" data-dropdown-toggle="dropdown" data-dropdown-trigger="click" class="text-black bg-white hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center inline-flex items-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800" type="button">6 <svg class="w-2.5 h-2.5 ms-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 10 6">
<path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 4 4 4-4"/>
</svg>
</button>


 <div id="dropdown" class="z-10 hidden bg-white divide-y divide-gray-100 rounded-lg shadow w-44 dark:bg-gray-700">
    <ul class="py-2 text-sm text-gray-700 dark:text-gray-200" aria-labelledby="dropdownHoverButton">
      <li>
        <a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Dashboard</a>
      </li>
      <li>
        <a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Settings</a>
      </li>
      <li>
        <a href="#" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Earnings</a>
      </li>
      <li>
         <a href="#"class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-600 dark:hover:text-white">Sign out</a>
      </li>
    </ul>
</div>  

<div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle bg-white text-black" type="button" data-bs-toggle="dropdown" aria-expanded="false">
    6
  </button>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" >20 June</a></li>
    <li><a class="dropdown-item" >27 June </a></li>
    <li><a class="dropdown-item" >4 July</a></li>
  </ul>
</div>
        </td>
    </tr>*/}

   
    
    
  </tbody>
</table>

</div>    

    </div>  

    </div>

  );
}



export default App;
