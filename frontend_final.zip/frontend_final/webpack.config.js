module.exports = {
    //...
    resolve: {
      extensions: ['.js', '.jsx']
    }
  };